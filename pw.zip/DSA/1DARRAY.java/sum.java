import java.util.Scanner;

class sum
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter a strinhhg");
        String s= sc.nextLine();

        System.out.println(s);
    }
}