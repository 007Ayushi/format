// Write a program that validates a user's password based on the following criteria (in the following order):

// § 1. The password must be at least 8 characters long.

// § 2. The password must contain at least one uppercase letter (A-Z).

// § 3. The password must contain at least one lowercase letter (a-z).

// § 4. The password must contain at least one digit (0-9).

// Take the following assumptions regarding the input:

// § The input will not contain any spaces

// Your output should print the rule that it violates exactly as defined above.

// If the password violates multiple rules then the first rule it violates should take priority

import java.util.*;
public class password {
    public static void Validatepassword(String password)
    {
    boolean hasupperCase=false, haslowerCase=false,hasdigit=false;
    Scanner sc=new Scanner(System.in);
    if(password.length()==8)
    {
        if(password==hasupperCase)
    }
    

    {

    }
    
    
}
}
