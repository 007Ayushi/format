import java.io.File;
import java.io.*;
class aditi
{
    public static void main(String[] args) {
        File f=new File("aditi.txt");
        System.out.println(f.exists());
    }
}