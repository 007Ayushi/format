
//`` backticks 
let age=20;
let exp=1;
console.log("My age is "+age+" and my exp is "+exp);//My age is 20 and my exp is 1
console.log(`My age is ${age} and my experience is ${exp}`);//My age is 20 and my experience is 1

//Rag"hav
//console.log("Rag"+"""+"hav");//error:missing ) after argument list

console.log("rag\"hav");//rag"hav
console.log(`rag"hav`);//rag"hav
console.log('rag"hav');//rag"hav
console.log(`rag'hav`);//rag'hav
