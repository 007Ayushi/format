age=20;
if(age>=18)console.log("adult");
else console.log("child");

num=2
if(num%2==0)console.log("even");
else console.log("odd number");

rating=5;
//1-poor 2-Below Average 3-Average 4-Good 5-Excellent
if(rating==1)console.log("poor");
else if(rating==2)console.log("Below Average");
else if(rating==3)console.log("Average");
else if(rating==4)console.log("Good");
else console.log("Excellent");

x=415;
if(x>=100 && x<=999)console.log("Three digit number");
else console.log("not a three digit Number");









