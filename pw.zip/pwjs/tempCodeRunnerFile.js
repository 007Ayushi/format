let obj1={
       "key":"value",
       "key2":"value2",
       "key3":"value3"

};
console.log(obj1);