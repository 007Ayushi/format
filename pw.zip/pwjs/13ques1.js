//write a code to generate a random integer between 0 and 9(included)
let num=Math.floor(Math.random()*10);
console.log(num);

//write code to generate a random integer between 0 and 10(included)
let num1=Math.floor(Math.random()*11);
console.log(num1);


//write a code to generate a random integer between -10 and 10(included)
let num2=Math.floor(Math.random()*20)-10;
console.log(num2);

if(Math.random()<0.5){
    console.log("hello");
}
else console.log("bye");