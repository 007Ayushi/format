function Oneton(){
    for(let i=1;i<=5;i++){
        console.log(i);
    }
}
Oneton(4);

function eqn(a,b){
    return (Math.abs(a*a)+Math.abs(b*b));
}
console.log(eqn(2,3))

function add(x,y){
    return x+y;
}
console.log(add(10,200));