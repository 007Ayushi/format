a=4;
b=3.14;
c="ayushi";
d=true;
e='q'

console.log(a,typeof(a));//number
console.log(b,typeof(b));//number
console.log(c,typeof(c));//string
console.log(d,typeof(d));//boolean
console.log(e,typeof e);//string

console.log('ayushi')
