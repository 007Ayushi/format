a=5;
b='5';//'5':53 ye string ke value ko sirf dekhta hai
console.log(a==b);//True//It only compares the value of both variable
console.log(a===b);//false//It compares both value and type.

for(let i=1;i<=10;i++){
   // console.log(i);
}

let j=1;
while(j<=5){
    console.log(j*5);
    j++;
}

let k=10;
do{
    console.log(k);
    k++;
}while(k<=14)

// for(let i=1;i<=5;i++){
//     for(let j=1;j<=i;j++){
//         console.log("*");
//     }
// }//prints every stars in different lines.


