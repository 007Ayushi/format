console.log("hello world");//hello world
console.log("hello ayushi");//hello ayushi
console.log("hii javascript");//hii javascript

// note:ctrl + backtick(top button of tab):use to open terminal
//to run file :write node filename.js in the terminal.

console.log(2+3);//5
console.log("2"+"3");//23

x=10;
console.log(x+10);//20
x="ayushi"
console.log(x);//ayushi
x=10.2
console.log(x);//10.2

b=5;
b*=3.14
console.log(b)//15.700000000000001

a=4;
b=6;
e=8
console.log(a,b,e);//4 6 8

console.log("ayushi","gupta","is","coding");//ayushi gupta is coding

age=20
console.log("my age is",age)//my age is 20
console.log("my age is "+age + "and i am young");//my age is 20and i am young



let c=2;
let d=4;
console.log(c+d);
console.log(c-d);
console.log(c*d);
console.log(c/d);
console.log(Math.floor(c/d));
console.log(c%d);
console.log(c**d);//c ka power d

let g=8;
g++;//9
console.log(g);




