import java.util.LinkedList;

public class display_elements {
    public static void main(String[] args) {
        queue<Integer> q=new LinkedList<Integer>();
        System.out.println(q.isEmpty());
    }
}
