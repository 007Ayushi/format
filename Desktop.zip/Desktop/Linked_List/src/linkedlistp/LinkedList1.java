package linkedlistp;
class Node{
    int val;
    Node next;
    Node(int val){
        this.val=val;
    }
public class LinkedList1{
    public static void main(String[] args) {
        Node a=new Node(10);
        System.out.println(a);
        Node b=new Node(20);
        Node c=new Node(30);
        Node d=new Node(40);
        Node e=new Node(50);

    }
}

}
