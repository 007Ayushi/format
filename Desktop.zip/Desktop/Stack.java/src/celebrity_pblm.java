public class celebrity_pblm {
    public static void main(String[] args) {

    }
}
