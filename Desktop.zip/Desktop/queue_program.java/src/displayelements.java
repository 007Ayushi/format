import java.util.LinkedList;

public class displayelements {
    public static  void main(String[] args) {
        Queue<Integer> q=new LinkedList<>();
    }
}
