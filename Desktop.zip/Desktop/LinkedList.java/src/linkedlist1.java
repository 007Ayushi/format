package LinkedList1;
public class linkedlist1 {

}
