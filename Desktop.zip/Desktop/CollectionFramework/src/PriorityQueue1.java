import java.util.PriorityQueue;

public class PriorityQueue1 {
    public static void main(String[] args) {
        PriorityQueue pq=new PriorityQueue();
        pq.add(100);
        pq.add(200);
        pq.add(300);
        System.out.println(pq);
    }
}
