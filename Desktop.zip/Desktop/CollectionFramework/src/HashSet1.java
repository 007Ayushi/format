import java.util.HashSet;

public class HashSet1 {
    public static void main(String[] args) {
        HashSet hs=new HashSet();
        hs.add(100);
        hs.add(200);
        hs.add(300);
        System.out.println(hs);
    }
}
