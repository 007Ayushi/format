private class class_Modifiers {
    public static void main(String[] args) {
        System.out.println("hello");
    }
}
