function Chai(){
    return(
        <h1>chai is ready</h1>
    )
}
export default Chai