import Chai from "./chai"
function App() {
  const username="chai aur code"
  return (
    <>
    <Chai/>
    <h1>hii its an App.jsx {username}</h1>
    <p>These empty opening and closing tags are called fragments.</p>
    <p>Use to werap more than 1tag bcoz it returns only 1 tag</p>
    </>
 
  )
}

export default App
