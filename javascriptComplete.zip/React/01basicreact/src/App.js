import Chai from "./Chai";
function App() {
  return (
    <>
    <Chai/>
   <h1>React series begins here</h1>
   </>
  );
}

export default App;
