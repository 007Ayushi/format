function Chai(){

    return(
        <h2>we have chai.js in src</h2>
    )
}

export default Chai