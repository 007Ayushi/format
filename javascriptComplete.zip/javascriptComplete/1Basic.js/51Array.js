//Array is an object which is resizable and collection of multiple elements.

const myArr={}
%DebugPrint(myArr)


